package base;

import ikiz.Cvity;
import ikiz.IkizIdare;

public class IkizApp{
    private static IkizIdare i;
    
    public static void main(String[] args){
        mainFunction();
    }

//İŞLEM YÖNTEMLERİ:
    static void mainFunction(){
        Cvity connection = new Cvity(Cvity.connectDB("root", "LINQSE.1177", "localhost", "doguturk2", 3306),
                "root", "LINQSE.1177", "doguturk2");
        if(IkizIdare.startIkizIdare(connection) == false){
            System.err.println("Sistem başlatılamadı!..");
            return;
        }
        i = IkizIdare.getIkizIdare();
//        ikizIdare.getIkizIdare().produceTable(new testSinifi());
//        ikizIdare.getIkizIdare().addRowToDB(new testSinifi());
//        i.test("testSinifi");
        Object[] veriler = i.getData(testSinifi.class);
        if(veriler != null){
            for(int sayac = 0; sayac < veriler.length; sayac++){
                System.out.println("\n\n\n");
                testSinifi i = (testSinifi) veriler[sayac];
                System.out.println("veriler[" + sayac + "].getClass().getName(): " + i.numara);
                System.out.println("veriler[" + sayac + "].getNamePublic(): " + i.getNamePublic());
            }
        }
    }
}