package ikiz.Services;

import java.util.Date;

public class DTService{
    private static DTService serv;

    public DTService() {
        
    }

//İŞLEM YÖNTEMLERİ
    public Date getTime(){
        return null;
    }
    public Date getTime(String timeText){
        return null;
    }

//ERİŞİM YÖNTEMLERİ:
    //ANA ERİŞİM YÖNTEMİ:
    public static DTService getService(){
        if(serv == null)
            serv = new DTService();
        return serv;
    }
}